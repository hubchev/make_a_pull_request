


library(haven)
library(dplyr)
yourdata <- read_dta("pwt71rgdpl.dta")
# Generate the lny variable using mutate from the dplyr package
pwt71rgdpl.data <- mutate(yourdata, lny = log(rgdpl))

# Calculate genlny
genlny <- log(pwt71rgdpl.data$rgdpl)

# Calculate gr50 using the available column names
gr50 <- (pwt71rgdpl.data$rgdpl - pwt71rgdpl.data$lny) / 50

# Create yinitbins using ifelse
pwt71rgdpl.data$yinitbins <- ifelse(pwt71rgdpl.data$year == 1960, cut(pwt71rgdpl.data$lny, breaks = 5), NA)

# Create quintile by adding 1 to yinitbins
pwt71rgdpl.data$quintile <- pwt71rgdpl.data$yinitbins + 1

# Filter the data for year == 1960 and use the table() function for summary statistics
summary_stats <- table(pwt71rgdpl.data$quintile[pwt71rgdpl.data$year == 1960], gr50[pwt71rgdpl.data$year == 1960])

# Calculate statistics for each quintile
summary_table <- pwt71rgdpl.data %>%
  group_by(quintile) %>%
  summarize(
    Mean = mean(rgdpl, na.rm = TRUE),
    SD = sd(rgdpl, na.rm = TRUE),
    Count = n_distinct(ctry)
  )

# Create a data frame with quintile labels
quintiles <- c("Poorest", "Second", "Third", "Fourth", "Richest")

# Merge the calculated statistics with the manual quantities
result <- merge(summary_table, quantities, by = "Quintile", all.x = TRUE)

# Print the result table
result

# Format the table using kable
table_html <- result %>%
  kable("html") %>%
  kable_styling(bootstrap_options = "striped", full_width = FALSE)

# Print the formatted table
print(table_html)

