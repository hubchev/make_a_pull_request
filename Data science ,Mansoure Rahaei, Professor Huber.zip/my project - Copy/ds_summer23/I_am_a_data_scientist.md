# I am a data scientist

Please put your first and second name here, link it to your GitHub profile, and provide the title of the paper that you aim to reproduce. 

- [Stephan Huber](https://github.com/hubchev): _Title of the paper_
 
- [Sonali Agrawal](https://github.com/SonaliAgraw): _Data_Science_report_Presentation_Vitthal-Shukla_Sonali-Agrawal_Huber_
- [Vitthal Shukla](https://github.com/VitthalGit): _Exploring Well Being in the UK between 2011 and 2014_
- [Katharina Wagner](https://github.com/Katwag99): _Measuring Human Capital_
- [Shekoofeh Ansari](https://github.com/shekoofehansari): _Diabetes and Related Factors_
- [Valeria Ortega Porles](https://github.com/VaalOP): _Hacking Gender Stereotypes: Girls’ Participation in Coding Clubs_
- [Aynur Didem Evin](https://github.com/didemevin): _Lie Prevalence, Lie Characteristics and Strategies of Self-reported Good Liars_
- [Natalie Halezki](https://github.com/HalNatalie): _Achieving Universal Health Insurance Coverage in the United States: Addressing Market Failures or Providing Social Floor?_
- [Masoumeh Teymourzadeh](https://github.com/Mastanetmr): _LGBTQ Economics_
- [Paras Negi](https://github.com/ParasNegi88): _Five Facts about Value-Added Exports and Implications for Macroeconomics and  Trade Research_
- [Ashifuddin Mandal](https://github.com/Ashifuddinmandal?tab=repositories): _Analyses Of LNG Plant Constructions Engineering Deliverables Progress, Planned & Forecast_
- [Bahar Dabir](https://github.com/BaharDabir/)): _Business Resilience During Covid-19_
- [Benedikt Klutmann/Steffen Scherrer](https://github.com/BenFrese): _Unveiling the Enigma of Penalty Shootouts_
- [Mansoure Rahaei](https://github.com/mansourerahaei): _Do Poverty Traps Exist_

Thanks. 
