## ----setup, include=FALSE-----------------------------------------------------
library("knitr")
knit_hooks$set(purl = hook_purl)

## ----figofme, echo=FALSE, fig.cap="Natnarin Muanrat", out.width = '20%', fig.align = 'center'----
knitr::include_graphics("IMG_8997.jpg")

## ----echo= F, fig.cap="The Effect of Population Aging on Economic Growth, the Labor Force, and Productivity", out.width="25%" , fig.align='center'----

knitr::include_graphics("Pic_covid.png",error = F)


## ----echo=FALSE, fig.align='center', fig.cap="Young Adults and Labor Markets in Africa", out.width="25%"----

knitr::include_graphics("Pic_young.png",error = F)


## ----echo=FALSE, fig.align='center', fig.cap="Created a new R Markdown file", out.width="50%"----
knitr::include_graphics("new_file.png", error = FALSE)


## ----echo=TRUE, message=FALSE-------------------------------------------------
setwd("/Users/rdeveloper/Library/Mobile Documents/com~apple~CloudDocs/Documents/Hochschole Fresenius-WS2022-MIBM/2 Semester MIBM/2 Data Science for Business | Prof. Huber/R_Project/Project report/Project report")

## ----echo=TRUE, message=FALSE-------------------------------------------------
getwd()

## ----echo=TRUE----------------------------------------------------------------
# This is an R code chunk ```{r}

## ----echo=FALSE, fig.align='center', fig.cap=" To include a BibTeX file in an R Markdown document", out.width="60%"----
knitr::include_graphics("cite.png",error = F)


## ----echo=FALSE, fig.align='center', fig.cap=" The BibTeX", out.width="60%"----
knitr::include_graphics("bid.png",error = F)


## ----echo=TRUE, message=FALSE-------------------------------------------------
#install.packages("devtools")
#library("devtools")
#devtools::install_github("benmarwick/wordcountaddin", type = "source", dependencies = T)
library("wordcountaddin")
wordcount <- wordcountaddin::word_count()

## ----echo=FALSE, fig.align='center', fig.cap="The output of the wordcount", out.width="60%"----
knitr::include_graphics("wordcount.png",error = F)


## ----fig.align='center', fig.cap="The BibTeX", include=FALSE, out.width="60%"----
knitr::include_graphics("bid.png",error = F)

## ----echo=TRUE, message=FALSE-------------------------------------------------

options(repos = "https://cloud.r-project.org/")
install.packages("haven")
install.packages("tidyverse")
library(haven)
library(tidyverse)

data <- read_dta("pooled_age18to24.dta")

## ----eval=FALSE, message=FALSE, include=FALSE---------------------------------
#  
#  # inspect data
#  names(data)
#  str(data)
#  head(data)
#  summary(data)
#  view(data)

## ----echo=TRUE, message=FALSE-------------------------------------------------
# filter by age 18 to 24
filtered_age18to24 <- data %>% filter(age18to24 == 1)
View(filtered_age18to24)
# str(filtered_age18to24)
# head(filtered_age18to24)

# filter by other ages
filtered_age_others <- data %>% filter(age18to24 == 0)
View(filtered_age_others)

# Load the African country codes mapping
african_country_mapping <- read.csv("~/Library/Mobile Documents/com~apple~CloudDocs/Documents/Hochschole Fresenius-WS2022-MIBM/2 Semester MIBM/2 Data Science for Business | Prof. Huber/R_Project/Project report/Project report/african_country_codes.csv")
head(african_country_mapping)

# Create new dataframe with continent column
data_with_continent <- data %>%
  mutate(continent = ifelse(country_dhs %in% african_country_mapping$code, "Africa", "Others"))

# Get share per continent
summary_per_continent <- data_with_continent %>%
  group_by(continent) %>%
  summarize(paidwk_total_all = sum(paidwk_all, na.rm = TRUE),
            unpaidwk_total_all = sum(unpaidwk_all, na.rm = TRUE),
            paidwk_total = sum(paidwk, na.rm = TRUE),
            unpaidwk_total = sum(unpaidwk, na.rm = TRUE))

view(summary_per_continent)

# Get column names
colnames(data)[2:16]

paidwk_all = "Paid work, as a share of all sample"
paidwk = "Paid work, as a share of workers"
unpaidwk = "Unpaid work, as a share of workers"
unpaidwk_all = "Unpaid work, as a share of all sample"

# Rename the column names in the dataframe
summary_per_continent_renamed <- summary_per_continent %>%
  rename(
    `Paid work, as a share of all sample` = paidwk_total_all,
    `Paid work, as a share of workers` = paidwk_total,
    `Unpaid work, as a share of workers` = unpaidwk_total,
    `Unpaid work, as a share of all sample` = unpaidwk_total_all
  )

library(ggplot2)
library(tidyr)

# Reshape the data into a longer format
summary_per_continent_long <- gather(summary_per_continent_renamed, key = "variable", value = "value", -continent)

# Define the updated annotations for the legend
annotations <- c(
  "paidwk_total_all" = "Paid work, as a share of all sample",
  "paidwk_total" = "Paid work, as a share of workers",
  "unpaidwk_total" = "Unpaid work, as a share of workers",
  "unpaidwk_total_all" = "Unpaid work, as a share of all sample"
)

# Create the bar chart with figures on top and updated annotations in the legend
ggplot(data = summary_per_continent_long, aes(x = value, y = continent, fill = continent)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_text(aes(label = value), hjust = -0.2, vjust = 0.5, color = "white", size = 3) +
  labs(x = "Value", y = "Continent") +
  ggtitle("Summary per Continent") +
  facet_wrap(~ variable, scales = "free", nrow = 1) +
  theme_minimal() +
  scale_fill_manual(
    values = c("Africa" = "steelblue", "Others" = "darkorange"),
    labels = annotations
  )


## ----echo= F, out.width="70%"-------------------------------------------------
knitr::include_graphics("fig_2.png",error = F)

## ----echo=TRUE, message=FALSE-------------------------------------------------

# Set the directory where the replication package is located
user <- "/Users/rdeveloper/Library/Mobile Documents/com~apple~CloudDocs/Documents/Hochschole Fresenius-WS2022-MIBM/2 Semester MIBM/2 Data Science for Business | Prof. Huber/R_Project/Project report/Project report" 

# directories
dat <- paste0(user, "") # source file
out <- paste0(user, "/output")

# Create directory if it doesn't exist
if (!dir.exists(out)) {
   dir.create(out)
}

# Install necessary packages if not installed
install.packages("readxl")
install.packages("dplyr")

# Importing the Excel files
library(readxl)
library(dplyr)

# read source data from excel
temp1 <- read_excel(path = paste0(dat, "/WPP2019_POP_F07_1_POPULATION_BY_AGE_BOTH_SEXES.xlsx"), 
                    sheet = "ESTIMATES", range = "A17:AC3842")
temp2 <- read_excel(path = paste0(dat, "/WPP2019_POP_F07_1_POPULATION_BY_AGE_BOTH_SEXES.xlsx"), 
                    sheet = "MEDIUM VARIANT", range = "A17:AC4352")

# Appending (binding) the two datasets
combined_data <- bind_rows(temp1, temp2)

# Rename column "Region, subregion, country or area *" to "Regionsubregioncountryorar"
names(combined_data)[names(combined_data) == "Region, subregion, country or area *"] <- "Regionsubregioncountryorar"

# Cleaning data
combined_data <- combined_data %>% 
  filter((Type=="Region" & tolower(Regionsubregioncountryorar) %in% c("africa", "asia", "europe", "latin america and the caribbean", "northern america", "oceania")) | 
           (Type=="World") | 
           (Type=="Income Group" & Regionsubregioncountryorar=="Low-income countries")) %>%
  mutate(region = as.factor(Regionsubregioncountryorar))

# Looping over specific columns to convert to numeric and divide by 100000
for(v in names(combined_data)[which(names(combined_data) %in% c(9:29))]) {
  combined_data[[v]] <- as.numeric(combined_data[[v]]) / 100000
}

# Encoding and modifying 'Variant'
combined_data <- combined_data %>%
  mutate(proj = as.numeric(as.factor(Variant)) - 1)

# Rename column "Reference date (as of 1 July)" to "Referencedateasof1July"
names(combined_data)[names(combined_data) == "Reference date (as of 1 July)"] <- "Referencedateasof1July"

# Dropping 'Index' and 'Variant' columns and renaming 'Referencedateasof1July' to 'year'
combined_data <- combined_data %>%
  select(-Index, -Variant) %>%
  rename(year = Referencedateasof1July)

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# FIGURE 1 - POPULATION SHARE, UN WPP DATA 								
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

# Install necessary packages
install.packages("tidyverse")
install.packages("janitor")
install.packages("scales")
install.packages("RColorBrewer")

# Load libraries
library(tidyverse)
library(janitor)
library(scales)
library(RColorBrewer)

# Rename required columns
names(combined_data)[names(combined_data) == "15-19"] <- "L"
names(combined_data)[names(combined_data) == "20-24"] <- "M"

# Convert 'L' and 'M' columns to numeric
combined_data$L <- as.numeric(combined_data$L)
combined_data$M <- as.numeric(combined_data$M)

# Add a new variable 'total1524'
combined_data <- combined_data %>%
  mutate(total1524 = L + M)

# Create a new dataset, removing specific observations
data_subset <- combined_data %>%
  select(year, region, proj, total1524) %>%
  filter(!(proj==1 & year==2020)) %>%
  clean_names()

# Wide to long format
data_long <- data_subset %>%
  pivot_wider(names_from = region, values_from = total1524, names_prefix = "total1524_")

# create list of column names
region_names <- unique(data_subset$region)

# Create share variables and add column names
for(i in region_names) {
  data_long <- data_long %>%
    mutate(!!paste0("share1524_world1524_", i) := !!sym(paste0("total1524_", i)) / `total1524_WORLD`)
}

# keep region Africa, Asia, Latin America, Europe, North America, Oceania
# remove Low-income countries, WORLD
col_names <- colnames(data_long)

# Back to long format
data_long2 <- data_long %>%
  pivot_longer(cols = starts_with("total1524_"), names_to = "region", values_to = "total1524") %>%
  pivot_longer(cols = starts_with("share1524_world1524_"), names_to = "share_region", values_to = "share1524_world1524")

# subset by removing unnecessary columns
data_long2 <- data_long2 %>%
  filter(!(share_region %in% c("share1524_world1524_WORLD", "share1524_world1524_Low-income countries")))

# Recreate the duplicate obs
data_long2 <- data_long2 %>%
  add_row(data_long2[data_long2$year==2020,]) %>%
  arrange(region, year)

# Replace 'proj' values
data_long2 <- data_long2 %>%
  group_by(region, year) %>%
  mutate(proj = replace(proj, year==2020 & row_number()==1, 1))

# Make sure the package is installed
if (!require(stringr)) {
 install.packages("stringr")
}

# Load the library
library(stringr)

# Remove the substring
# clean up values in column region by removing leading string total1524_ from region
data_long2$region <- str_replace_all(data_long2$region, "total1524_", "")

data_long2 <- data_long2[str_detect(data_long2$share_region, fixed(data_long2$region)), ]

# Start Plotting the chart
colorblind_palette <- brewer.pal(8, "Set1")

ggplot(data = data_long2, aes(x = year, y = share1524_world1524)) +
  geom_line(aes(color = as.factor(region), linetype = as.factor(proj))) +
  scale_color_manual(values = colorblind_palette) +
  scale_linetype_manual(values = c("solid", "dashed")) +
  theme_minimal() +
  theme(legend.position = "bottom", legend.box = "horizontal") +
  labs(x = "", y = "", 
       title = "Population Age 15-24, by Region", 
       subtitle = "as a share of world population age 15-24", 
       color = "", linetype = "") +
  scale_x_continuous(breaks = seq(1960, 2100, 20)) +
  scale_y_continuous(labels = percent) +
  guides(color = guide_legend(nrow = 2, byrow = TRUE)) 

# Exporting plots
ggsave(filename = paste0(out, "/figure1_cohort_size.png"))
ggsave(filename = paste0(out, "/figure1_cohort_size.pdf"))


## ----echo=FALSE, message=FALSE------------------------------------------------
# install.packages("devtools")
# library("devtools")
# devtools::install_github("benmarwick/wordcountaddin", type = "source", dependencies = T)
library("wordcountaddin")
wordcount <- wordcountaddin::word_count()

