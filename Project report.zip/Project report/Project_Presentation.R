## ----setup, include=FALSE-----------------------------------------------------
library("knitr")
knit_hooks$set(purl = hook_purl)

## ----echo= F, out.width="25%"-------------------------------------------------
knitr::include_graphics("IMG_8997.jpg",error = F)


## ----echo= F, out.width="25%"-------------------------------------------------
knitr::include_graphics("Pic_covid.png",error = F)


## ----echo= F, out.width="25%"-------------------------------------------------
knitr::include_graphics("Pic_young.png",error = F)


## ----echo= F, out.width="100%"------------------------------------------------
knitr::include_graphics("new_file.png",error = F)


## ----echo=TRUE, message=FALSE-------------------------------------------------
setwd("/Users/rdeveloper/Library/Mobile Documents/com~apple~CloudDocs/Documents/Hochschole Fresenius-WS2022-MIBM/2 Semester MIBM/2 Data Science for Business | Prof. Huber/R_Project/Project report/Project report")

## ----echo=TRUE, message=FALSE-------------------------------------------------
getwd()

## ----echo=TRUE----------------------------------------------------------------
# This is an R code chunk ```{r}

## ----echo= F, out.width="100%"------------------------------------------------
knitr::include_graphics("cite.png",error = F)


## ----echo= F, out.width="100%"------------------------------------------------
knitr::include_graphics("bid.png",error = F)


## ----echo=TRUE, message=FALSE-------------------------------------------------
#install.packages("devtools")
#library("devtools")
#devtools::install_github("benmarwick/wordcountaddin", type = "source", dependencies = T)
library("wordcountaddin")
wordcount <- wordcountaddin::word_count()

## ----echo= F, out.width="100%"------------------------------------------------
knitr::include_graphics("wordcount.png",error = F)


## ----echo=TRUE, message=FALSE-------------------------------------------------

options(repos = "https://cloud.r-project.org/")
install.packages("haven")
install.packages("tidyverse")
library(haven)
library(tidyverse)

data <- read_dta("pooled_age18to24.dta")

## ----eval=FALSE, message=FALSE, include=FALSE---------------------------------
#  
#  # inspect data
#  names(data)
#  str(data)
#  head(data)
#  summary(data)
#  view(data)

## ----echo=TRUE, message=FALSE-------------------------------------------------
# filter by age 18 to 24
filtered_age18to24 <- data %>% filter(age18to24 == 1)
View(filtered_age18to24)
# str(filtered_age18to24)
# head(filtered_age18to24)

# filter by other ages
filtered_age_others <- data %>% filter(age18to24 == 0)
View(filtered_age_others)

# Load the African country codes mapping
african_country_mapping <- read.csv("~/Library/Mobile Documents/com~apple~CloudDocs/Documents/Hochschole Fresenius-WS2022-MIBM/2 Semester MIBM/2 Data Science for Business | Prof. Huber/R_Project/Project report/Project report/african_country_codes.csv")
head(african_country_mapping)

# Create new dataframe with continent column
data_with_continent <- data %>%
  mutate(continent = ifelse(country_dhs %in% african_country_mapping$code, "Africa", "Others"))

# Get share per continent
summary_per_continent <- data_with_continent %>%
  group_by(continent) %>%
  summarize(paidwk_total_all = sum(paidwk_all, na.rm = TRUE),
            unpaidwk_total_all = sum(unpaidwk_all, na.rm = TRUE),
            paidwk_total = sum(paidwk, na.rm = TRUE),
            unpaidwk_total = sum(unpaidwk, na.rm = TRUE))

view(summary_per_continent)

# Get column names
colnames(data)[2:16]

paidwk_all = "Paid work, as a share of all sample"
paidwk = "Paid work, as a share of workers"
unpaidwk = "Unpaid work, as a share of workers"
unpaidwk_all = "Unpaid work, as a share of all sample"

# Rename the column names in the dataframe
summary_per_continent_renamed <- summary_per_continent %>%
  rename(
    `Paid work, as a share of all sample` = paidwk_total_all,
    `Paid work, as a share of workers` = paidwk_total,
    `Unpaid work, as a share of workers` = unpaidwk_total,
    `Unpaid work, as a share of all sample` = unpaidwk_total_all
  )

library(ggplot2)
library(tidyr)

# Reshape the data into a longer format
summary_per_continent_long <- gather(summary_per_continent_renamed, key = "variable", value = "value", -continent)

# Define the updated annotations for the legend
annotations <- c(
  "paidwk_total_all" = "Paid work, as a share of all sample",
  "paidwk_total" = "Paid work, as a share of workers",
  "unpaidwk_total" = "Unpaid work, as a share of workers",
  "unpaidwk_total_all" = "Unpaid work, as a share of all sample"
)

# Create the bar chart with figures on top and updated annotations in the legend
ggplot(data = summary_per_continent_long, aes(x = value, y = continent, fill = continent)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_text(aes(label = value), hjust = -0.2, vjust = 0.5, color = "white", size = 3) +
  labs(x = "Value", y = "Continent") +
  ggtitle("Summary per Continent") +
  facet_wrap(~ variable, scales = "free", nrow = 1) +
  theme_minimal() +
  scale_fill_manual(
    values = c("Africa" = "steelblue", "Others" = "darkorange"),
    labels = annotations
  )


## ----echo= F, out.width="100%"------------------------------------------------
knitr::include_graphics("fig_2.png",error = F)


## ----echo=FALSE, message=FALSE------------------------------------------------
#install.packages("devtools")
#library("devtools")
#devtools::install_github("benmarwick/wordcountaddin", type = "source", dependencies = T)
library("wordcountaddin")
wordcount <- wordcountaddin::word_count()

