# Data prep
library(readxl)

# Import UN data - ESTIMATES sheet
data_estimates <- read_excel("/Users/rdeveloper/Downloads/WPP2019_POP_F07_1_POPULATION_BY_AGE_BOTH_SEXES.xlsx", sheet = "ESTIMATES", range = "A17:AC3842", col_names = TRUE)

# Import UN data - MEDIUM VARIANT sheet
data_medium_variant <- read_excel("/Users/rdeveloper/Downloads/WPP2019_POP_F07_1_POPULATION_BY_AGE_BOTH_SEXES.xlsx", sheet = "MEDIUM VARIANT", range = "A17:AC4352", col_names = TRUE)

# Append data_estimates and data_medium_variant
data_combined <- rbind(data_medium_variant, data_estimates)

# Rename column "Region, subregion, country or area *" to "Regionsubregioncountryorar"
names(data_combined)[names(data_combined) == "Region, subregion, country or area *"] <- "Regionsubregioncountryorar"

# Clean data
data_combined <- subset(data_combined, Type == "Region" & grepl("(africa|asia|europe|latin america and the caribbean|northern america|oceania)", tolower(Regionsubregioncountryorar), ignore.case = TRUE) |
                          Type == "World" |
                          (Type == "Income Group" & Regionsubregioncountryorar == "Low-income countries")
)

# Encode variables
data_combined$region <- as.integer(factor(data_combined$Regionsubregioncountryorar))

# Convert numeric columns
# numeric_cols <- names(data_combined)[sapply(data_combined, is.numeric)]
# data_combined[, numeric_cols] <- lapply(data_combined[, numeric_cols], function(x) as.numeric(gsub(",", "", x))/100000)

# Convert "Reference date (as of 1 July)" column to integer
data_combined$year <- as.integer(data_combined$`Reference date (as of 1 July)`)

# Create 'proj' variable
data_combined$proj <- as.integer(factor(data_combined$Variant))
data_combined$proj <- data_combined$proj - 1

# Remove the original "Reference date (as of 1 July)" column
data_combined <- subset(data_combined, select = -`Reference date (as of 1 July)`)

################ plotting chart ##########################

library(ggplot2)

# Rename the column Type to region
# names(data_combined)[names(data_combined) == "Type"] <- "region"

# Rename columns
names(data_combined)[names(data_combined) == "15-19"] <- "L"
names(data_combined)[names(data_combined) == "20-24"] <- "M"

# Convert 'L' and 'M' columns to numeric
data_combined$L <- as.numeric(data_combined$L)
data_combined$M <- as.numeric(data_combined$M)

# Calculate total1524 column
data_combined$total1524 <- data_combined$L + data_combined$M

# Filter and select necessary variables
data_filtered <- subset(data_combined, select = c(year, region, proj, total1524))

# Drop duplicate observations
data_filtered <- subset(data_filtered, !(proj == 1 & year == 2020))

# Reshape the data wide to calculate the share
# data_wide <- reshape(data_filtered, idvar = c("year", "proj"), timevar = "region", direction = "wide")

library(tidyverse)

# Reshape the data wide to calculate the share
data_wide <- data_filtered %>%
  pivot_wider(names_from = region, values_from = total1524) %>%
  select(-proj)

# Update column names in data_wide
colnames(data_wide) <- gsub("total1524", "L_", colnames(data_wide))

### error #### -> make it work

# Calculate the share for each region
for (i in 1:7) {
  data_wide[, paste0("share1524_world1524", i)] <- data_wide[, paste0("L_", i)] / data_wide[, "total15248"]
}


# Reshape the data long
data_long <- reshape(data_wide, varying = c(paste0("total1524", 1:7), paste0("share1524_world1524", 1:7)),
                     v.names = c("total1524", "share1524_world1524"),
                     timevar = "region",
                     times = 1:7,
                     idvar = c("year", "proj"),
                     direction = "long")

# Expand 2020 observations
data_long <- rbind(data_long, data_long[data_long$year == 2020, ])

# Sort the data
data_long <- data_long[order(data_long$region, data_long$year), ]

# Update proj for 2020 observations
data_long$proj[data_long$year == 2020 & !duplicated(data_long$region)] <- 1

# Plot the graph
ggplot(data_long, aes(x = year, y = share1524_world1524, color = as.factor(region), linetype = as.factor(proj))) +
  geom_line(size = 1) +
  scale_color_manual(values = c("#000000", "#FF0000", "#0000FF", "#008000", "#FFA500", "#800080", "#FFFF00")) +
  scale_linetype_manual(values = c("solid", "dashed")) +
  xlab("") +
  ylab("") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  labs(title = "Population Age 15-24, by Region",
       subtitle = "as a share of world population age 15-24") +
  guides(color = guide_legend(override.aes = list(size = 1))) +
  guides(linetype = guide_legend(override.aes = list(size = 1))) +
  guides(color = guide_legend(order = 1:7,
                              title = "Region",
                              title.position = "top",
                              nrow = 2,
                              label.position = "right",
                              label.hjust = 0.5,
                              label.vjust = 0.5,
                              label.size = "small")) +
  scale_x_continuous(breaks = seq(1960, 2100, by = 20), labels = seq(1960, 2100, by = 20), expand = c(0, 0)) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 0.01), expand = c(0, 0))

# Save the graph
ggsave(filename = "/path/to/figure1_cohort_size.png", device = "png", plot = last_plot(), width = 6, height = 4, dpi = 300)
ggsave(filename = "/path/to/figure1_cohort_size.pdf", device = "pdf", plot = last_plot(), width = 6, height = 4)
