## ----setup, include=FALSE-----------------------------------------------------
library("knitr")
knit_hooks$set(purl = hook_purl)

## -----------------------------------------------------------------------------
#library(haven)
#dataset <- read_dta(file = "Nameofyourfile")
#View(dataset)

## -----------------------------------------------------------------------------
# Set directory
setwd("/Users/valeria/IBM (M.A.)/2nd Semester/Data Science/Paper Project")

# Load packages
library(dplyr)
library(tidyverse)
library(haven)
library(kableExtra)


# Import file and save
data.stata <- read_dta(file="Data_CarlanaFort2022.dta")
# View(data.stata)

## -----------------------------------------------------------------------------
# Filter the data for one variable: data_stem_mum
data_stem_mum <- filter(data.stata, data.stata[, 2] == 1)
data_not_stem_mum <- filter(data.stata, data.stata[, 2] == 0)

# Count the number of males and females
gender_counts_mum_stem <- table(data_stem_mum$female)
gender_counts_mum_not_stem <- table(data_not_stem_mum$female)

# Extract the count for males and females
num_male_mum_stem <- gender_counts_mum_stem[1]
num_female_mum_stem <- gender_counts_mum_stem[2]
num_male_mum_not_stem <- gender_counts_mum_not_stem[1]
num_female_mum_not_stem <- gender_counts_mum_not_stem[2]


M41 = round(num_male_mum_stem/(num_male_mum_stem +  num_male_mum_not_stem),3)
M42 = round(num_female_mum_stem/(num_female_mum_stem +  num_female_mum_not_stem),3)

# Print the results
cat("males with STEM Mums:", M41, "\n")
cat("females with STEM Mums:", M42, "\n")

## -----------------------------------------------------------------------------
# Extract the count for males and females
# [ , 1] gives ONLY the first column of the array but all rows (as the left entry is blanc = ALL) 

#Table is counting how often a unique entry appears in the list, here it is wither 0 or 1
gender_counts <- table(data.stata[ , 1])

#all the males are 0 the first unique number in the array
# gender_counts is NOT 2D even if it looks like it. It is a 1D array with a header that can be misinterpreted as an own data row
num_male <- gender_counts[1]

#all females are 1, so the second unique number in the array
num_female <- gender_counts[2]


## -----------------------------------------------------------------------------
# c() creates an empty array
mean_table_data <- c()

# Assign start and end column that shall be analyzed column 23 is the "male" column which is redundant with column 1
col_start = 2
col_end = 22

## -----------------------------------------------------------------------------
# 21 times, this loop executes the same code. However, the column number changes every time by 1.
for (i in col_start:col_end) {
  
  #The comments below are written only for column number 2 but the idea remains the same for all columns

  # Filter the data for Mum works in STEM 
  # Two new 2D arrays are created. data_true saves all "1" and data_false all "0" but not "NA"!!! That is a crutial point for the normalization later on
  
  data_true <- data.stata[data.stata[, i] == 1, ]
  data_false <- data.stata[data.stata[, i] != 1, ]
  

  # data_true deletes all rows that are not 1. So if we look at the first column now, we have all males and females with mums in stem
  # Count the number of males and females whose Mums work in STEM
  gender_counts_true <- table(data_true[, 1])
  gender_counts_false <- table(data_false[, 1])

  # Extract the count for males and females whose Mums work in STEM
  num_male_true <- gender_counts_true[1]
  num_female_true <- gender_counts_true[2]

  num_male_false <- gender_counts_false[1]
  num_female_false <- gender_counts_false[2]

  # Generate "mean" values
  mean_male = round(num_male_true /(num_male_true + num_male_false),3)
  mean_female = round(num_female_true /(num_female_true + num_female_false),3)

  mean_table_data <- c(mean_table_data, mean_male, mean_female)

}

cat("Full Mean list", mean_table_data, "\n")

## -----------------------------------------------------------------------------
# Create a sample data frame
Variable = c("Mums in STEM","DADS in STEM","3","4","5","6","7","8","9","10","11")

Boys <- c()
  for(i in 1:11){
    Boys <- c(Boys, mean_table_data[2*i-1])
  }
Girls <- c()
  for(i in 1:11){
    Girls <- c(Girls, mean_table_data[2*i])
  }

#data.frame=store values
data <- data.frame(
  Variable,
  Boys,
  Girls
)


## -----------------------------------------------------------------------------
# Convert the data frame to a table with scientific notation
formatted_table <- kable(data, format = "html", digits = 3, scientific = TRUE)

# Add styling and customization to the table
styled_table <- kable_styling(formatted_table, full_width = FALSE)

# Print the table
print(styled_table)

## ----echo=TRUE, message=FALSE-------------------------------------------------
#install.packages("devtools")
#library("devtools")
#devtools::install_github("benmarwick/wordcountaddin", type = "source", dependencies = T)
library("wordcountaddin")
wordcount <- wordcountaddin::word_count( )

## ---- echo=FALSE--------------------------------------------------------------
# This code chunk is for citation rendering only


