The following files replicate the results presented in the main text and appendix of "The Rise and Decline of General Laws of Capitalism", forthcoming in the Journal of Economic Perspectives.

To use the files, extract them into a common folder, and sset it up as the current directory in all Stata do-files.  The files were created in Stata 13. 

The zip file contains the following files:
DataPiketty: contains the data used in the regressions.
FigureData1, FigureData2, FigureData3: contain the data used in the figures, and obtained from several sources as indicated in the text. 
Table1.do: Runs all the regressions presented in Table 1 and Table A1 in the appendix.
Table A2, Table A3 Table A4 Table A5: Estimate the models presented in the appendix tables.
Figures: Plots the figures  presented in the main text. 
 